"""Driver script executed under py-spy to generate the flame graph.
Runs BFS and DFS repeatedly on the largest maze so there is enough
wall-clock time for the sampling profiler to collect meaningful samples.
"""
import time
from maze_core import generate_maze, bfs, dfs

open_edges, neighbors_of = generate_maze(26, 26, 3)
start, goal = (0, 0), (25, 25)

t_end = time.perf_counter() + 3.0  # keep the process alive ~3s for py-spy
iterations = 0
while time.perf_counter() < t_end:
    bfs(start, goal, open_edges, neighbors_of)
    dfs(start, goal, open_edges, neighbors_of, depth_limit=400)
    iterations += 1

print("iterations completed:", iterations)
