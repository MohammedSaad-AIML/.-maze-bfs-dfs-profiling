import random
from collections import deque

def generate_maze(width, height, seed):
    """Recursive-backtracker maze generator. Returns a set of open (non-wall) cells
    and an adjacency function. Grid is (width x height) cells; walls are the
    connections NOT carved between cells."""
    rng = random.Random(seed)
    cells = [(x, y) for x in range(width) for y in range(height)]
    visited = set()
    open_edges = set()  # frozenset({cellA, cellB}) pairs that are passable

    def neighbors_of(cell):
        x, y = cell
        cand = [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]
        return [c for c in cand if 0 <= c[0] < width and 0 <= c[1] < height]

    start = (0, 0)
    stack = [start]
    visited.add(start)
    while stack:
        current = stack[-1]
        unvisited_n = [n for n in neighbors_of(current) if n not in visited]
        if unvisited_n:
            nxt = rng.choice(unvisited_n)
            open_edges.add(frozenset((current, nxt)))
            visited.add(nxt)
            stack.append(nxt)
        else:
            stack.pop()
    return open_edges, neighbors_of

def get_neighbors(cell, open_edges, neighbors_of):
    """Return only neighbours reachable through a carved (open) passage."""
    result = []
    for n in neighbors_of(cell):
        if frozenset((cell, n)) in open_edges:
            result.append(n)
    return result

def bfs(start, goal, open_edges, neighbors_of):
    frontier = deque([start])
    came_from = {start: None}
    nodes_expanded = 0
    while frontier:
        current = frontier.popleft()
        nodes_expanded += 1
        if current == goal:
            break
        for n in get_neighbors(current, open_edges, neighbors_of):
            if n not in came_from:
                came_from[n] = current
                frontier.append(n)
    if goal not in came_from:
        return None, nodes_expanded
    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = came_from[node]
    path.reverse()
    return path, nodes_expanded

def dfs(start, goal, open_edges, neighbors_of, depth_limit=200):
    stack = [(start, [start])]
    visited = set()
    nodes_expanded = 0
    while stack:
        current, path = stack.pop()
        nodes_expanded += 1
        if current == goal:
            return path, nodes_expanded
        if len(path) > depth_limit:
            continue
        if current in visited:
            continue
        visited.add(current)
        for n in get_neighbors(current, open_edges, neighbors_of):
            if n not in path:
                stack.append((n, path + [n]))
    return None, nodes_expanded
