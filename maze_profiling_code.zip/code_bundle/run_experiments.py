import json, time
from maze_core import generate_maze, bfs, dfs

CONFIGS = [
    ("Best case (10x10 maze)", 10, 10, 1),
    ("Average case (18x18 maze)", 18, 18, 2),
    ("Worst case (26x26 maze)", 26, 26, 3),
]
RUNS = 5
DEPTH_LIMIT = 400

results = []
for label, w, h, seed in CONFIGS:
    open_edges, neighbors_of = generate_maze(w, h, seed)
    start, goal = (0, 0), (w - 1, h - 1)

    bfs_times, dfs_times = [], []
    bfs_nodes = dfs_nodes = None
    bfs_path_len = dfs_path_len = None

    for _ in range(RUNS):
        t0 = time.perf_counter()
        path, nodes = bfs(start, goal, open_edges, neighbors_of)
        t1 = time.perf_counter()
        bfs_times.append((t1 - t0) * 1000)
        bfs_nodes, bfs_path_len = nodes, (len(path) - 1 if path else None)

    for _ in range(RUNS):
        t0 = time.perf_counter()
        path, nodes = dfs(start, goal, open_edges, neighbors_of, DEPTH_LIMIT)
        t1 = time.perf_counter()
        dfs_times.append((t1 - t0) * 1000)
        dfs_nodes, dfs_path_len = nodes, (len(path) - 1 if path else None)

    results.append({
        "label": label, "width": w, "height": h, "seed": seed,
        "bfs": {"times_ms": bfs_times, "avg_ms": sum(bfs_times)/len(bfs_times),
                "nodes": bfs_nodes, "path_len": bfs_path_len},
        "dfs": {"times_ms": dfs_times, "avg_ms": sum(dfs_times)/len(dfs_times),
                "nodes": dfs_nodes, "path_len": dfs_path_len},
    })

with open("results.json", "w") as f:
    json.dump(results, f, indent=2)

for r in results:
    print(r["label"])
    print("  BFS: avg=%.4fms nodes=%d path=%s" % (r["bfs"]["avg_ms"], r["bfs"]["nodes"], r["bfs"]["path_len"]))
    print("  DFS: avg=%.4fms nodes=%d path=%s" % (r["dfs"]["avg_ms"], r["dfs"]["nodes"], r["dfs"]["path_len"]))
