import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from maze_core import generate_maze, bfs

w, h = 18, 18
open_edges, neighbors_of = generate_maze(w, h, 2)
start, goal = (0, 0), (w - 1, h - 1)
path, nodes_expanded = bfs(start, goal, open_edges, neighbors_of)

fig, ax = plt.subplots(figsize=(6, 6))
cell = 1.0

# draw walls: for every pair of adjacent cells NOT in open_edges, draw a wall segment
for x in range(w):
    for y in range(h):
        neighbours = [(x+1, y), (x, y+1)]
        for nx, ny in neighbours:
            if nx >= w or ny >= h:
                continue
            if frozenset(((x, y), (nx, ny))) not in open_edges:
                if nx == x + 1:  # wall between (x,y)-(x+1,y): vertical line
                    ax.plot([x+1, x+1], [y, y+1], color="black", linewidth=1.2)
                else:  # wall between (x,y)-(x,y+1): horizontal line
                    ax.plot([x, x+1], [y+1, y+1], color="black", linewidth=1.2)

# outer border
ax.plot([0, w], [0, 0], color="black", linewidth=2)
ax.plot([0, w], [h, h], color="black", linewidth=2)
ax.plot([0, 0], [0, h], color="black", linewidth=2)
ax.plot([w, w], [0, h], color="black", linewidth=2)

# path with numbered nodes (every 6th node labeled to keep it readable)
xs = [p[0] + 0.5 for p in path]
ys = [p[1] + 0.5 for p in path]
ax.plot(xs, ys, color="#e6522c", linewidth=2.2, zorder=3, label="BFS shortest path")
for i, (px, py) in enumerate(zip(xs, ys)):
    if i == 0 or i == len(xs) - 1 or i % 6 == 0:
        ax.scatter([px], [py], color="#1f77b4", s=28, zorder=4)
        ax.annotate(str(i), (px, py), textcoords="offset points", xytext=(0, 6),
                    fontsize=7, ha="center", color="#1f2933")

ax.scatter([start[0]+0.5], [start[1]+0.5], color="green", s=90, zorder=5, marker="s", label="Start (node 0)")
ax.scatter([goal[0]+0.5], [goal[1]+0.5], color="red", s=90, zorder=5, marker="*", label=f"Goal (node {len(path)-1})")

ax.set_xlim(-0.5, w + 0.5)
ax.set_ylim(-0.5, h + 0.5)
ax.set_aspect("equal")
ax.axis("off")
ax.set_title(f"18x18 Maze -- BFS solution path ({len(path)-1} moves, {nodes_expanded} nodes expanded)", fontsize=10)
ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.02), ncol=3, fontsize=8, frameon=False)
plt.tight_layout()
plt.savefig("maze_fig1.png", dpi=170)
print("saved maze_fig1.png, path length", len(path)-1, "nodes_expanded", nodes_expanded)
