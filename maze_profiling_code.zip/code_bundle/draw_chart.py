import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

with open("results.json") as f:
    results = json.load(f)

labels = [r["label"].split(" (")[0] for r in results]
bfs_avg = [r["bfs"]["avg_ms"] for r in results]
dfs_avg = [r["dfs"]["avg_ms"] for r in results]

x = np.arange(len(labels))
width = 0.35
fig, ax = plt.subplots(figsize=(5.5, 3.4))
ax.bar(x - width/2, bfs_avg, width, label="BFS", color="#2e86ab")
ax.bar(x + width/2, dfs_avg, width, label="DFS", color="#e6522c")
ax.set_ylabel("Average time (ms)")
ax.set_title("Average execution time: BFS vs DFS across test cases")
ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=8)
ax.legend()
plt.tight_layout()
plt.savefig("chart_time.png", dpi=170)

bfs_nodes = [r["bfs"]["nodes"] for r in results]
dfs_nodes = [r["dfs"]["nodes"] for r in results]
fig, ax = plt.subplots(figsize=(5.5, 3.4))
ax.bar(x - width/2, bfs_nodes, width, label="BFS", color="#2e86ab")
ax.bar(x + width/2, dfs_nodes, width, label="DFS", color="#e6522c")
ax.set_ylabel("Nodes expanded")
ax.set_title("Nodes expanded: BFS vs DFS across test cases")
ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=8)
ax.legend()
plt.tight_layout()
plt.savefig("chart_nodes.png", dpi=170)
print("charts saved")
